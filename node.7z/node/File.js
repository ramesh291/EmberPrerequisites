var fs=require("fs");
fs.readFile('OS.JS',function(err,data){
if(err){
return console.error(err);
}
console.log("aysch read:"+data.toString());
});