var http= require('http');
var fs=require('fs');
var url=require('url');
http.createServer(function (request,response)
{
response.write("hiiiiiiii");
}
).listen(8081);

console.log('Server running at http:/127.0.0.1:8081/');